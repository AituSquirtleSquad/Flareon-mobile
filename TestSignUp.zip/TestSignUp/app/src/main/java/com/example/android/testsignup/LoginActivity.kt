package com.example.android.testsignup

class LoginActivity {
}