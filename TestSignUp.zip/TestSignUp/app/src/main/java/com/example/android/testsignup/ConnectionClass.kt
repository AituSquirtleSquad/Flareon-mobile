package com.example.android.testsignup

class ConnectionClass {
    val ip: String  = "" // SQL Server IP Address
    val username: String  = "" // SQL Server User name
    val pass: String  = "" // SQL Server Password
    val db: String  = "" // SQL Server Database
}